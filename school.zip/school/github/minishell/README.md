# minishell
It's c program to run shell commands. 
In this program lexer and parser are redefined for learning purpose.
