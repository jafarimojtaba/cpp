# 42-Cursus-Tester

Testing program for projects within the 42 course.

Currently pretty early version and just openning so a fellow course mates to see if they break anything so far.
