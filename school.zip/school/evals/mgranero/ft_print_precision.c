/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_precision.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/23 14:49:03 by mgranero          #+#    #+#             */
/*   Updated: 2022/08/28 23:25:47 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf_bonus.h"

static int	ft_case2(char *buff, int min, int len);

int	ft_print_precision(char *buff, int min, int max, int len)
{
	int	cnt_char;

	cnt_char = 0;
	if (len >= max && max > 0)
	{
		ft_print_buffer(buff, max, 0);
		cnt_char -= len - max;
	}
	else if (len <= min && min > 0)
		cnt_char += ft_case2(buff, min, len);
	else if (max == 0)
		return (-1 * len);
	else
		ft_print_buffer(buff, len, 0);
	return (cnt_char);
}

static int	ft_case2(char *buff, int min, int len)
{
	int	temp;
	int	init;
	int	cnt_char;

	temp = len;
	init = 0;
	cnt_char = 0;
	if (buff[0] == '-')
	{
		ft_handle_print_txt('-');
		init = 1;
		min += 1;
	}		
	while (len < min)
	{
		cnt_char += ft_handle_print_txt('0');
		len++;
	}
	ft_print_buffer(buff, temp, init);
	return (cnt_char);
}
