/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_handle_print_width_precision.c                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/20 10:37:33 by mgranero          #+#    #+#             */
/*   Updated: 2022/08/28 23:25:34 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
 An optional precision, in the form of a period ('.') followed by 
 an optional decimal digit string.
 If the precision is given as just '.', or the precision is negative, 
 the precision is taken to be zero.

DIGITS
 d, i, o, u, x, and X conversions gives the minimum number of digits

 STRING
 the maximum number of characters to be printed from a string for s 
 and S conversions.

 Returns:
 The number of characteres printed
*/

#include "ft_printf_bonus.h"

static int	ft_get_digits_width(const char *str, int *i);
static int	ft_number_and_width_zero(const char *str, int *i,
				va_list list, char *buff);

int	ft_handle_print_width_precision(const char *str, va_list list, int *i)
{
	char	buff[1000];
	int		cnt_char;

	ft_initialize_parameters(buff, &cnt_char);
	cnt_char = ft_get_width_precision(str, buff, i, list);
	return (cnt_char);
}

int	ft_get_width_precision(const char *str, char *buff,
			int *i, va_list list)
{
	int	width;
	int	precision;
	int	cnt_char;
	int	min_max[2];
	int	len;

	min_max[0] = -1;
	min_max[1] = -1;
	cnt_char = 0;
	len = 0;
	width = ft_get_digits_width(str, i);
	precision = ft_get_digits_precision(str, i);
	if (precision == 0 && width == 0)
		return (ft_number_and_width_zero(str, i, list, buff));
	if (str[*i] == 's')
		min_max[1] = precision;
	else if (str[*i] == 'd' || str[*i] == 'i' || str[*i] == 'u'
		|| str[*i] == 'x' || str[*i] == 'X')
		min_max[0] = precision;
	len = ft_handle_print_by_data_type(str, buff, list, i);
	if (len < 0)
		len *= -1;
	cnt_char += ft_print_width(min_max[0], min_max[1], width, len);
	cnt_char += ft_print_precision(buff, min_max[0], min_max[1], len);
	return (cnt_char);
}

static int	ft_number_and_width_zero(const char *str, int *i,
			va_list list, char *buff)
{
	int	len;
	int	cnt_char;

	len = 0;
	cnt_char = 0;
	if (str[*i] != 's')
	{
		len = ft_handle_print_by_data_type(str, buff, list, i);
		if (len < 0)
			len *= -1;
		if (buff[0] == '0' && (str[*i] == 'i' || str[*i] == 'd'
				|| str[*i] == 'u' || str[*i] == 'x' || str[*i] == 'X'))
			cnt_char = 0;
		else
		{
			ft_print_buffer(buff, len, 0);
			cnt_char += len;
		}
	}
	return (cnt_char);
}

static int	ft_get_digits_width(const char *str, int *i)
{
	int	width;

	width = -1;
	if (ft_isdigit(str[*i + 1]) == 1)
	{
		width = ft_get_digits(str + *i +1, i);
		*i = *i + 1;
	}
	else if (str[*i + 1] == '.')
		width = 0;
	return (width);
}

int	ft_get_digits_precision(const char *str, int *i)
{
	int	precision;

	precision = -1;
	if (str[*i + 1] == '.' && ft_isdigit(str[*i + 2]) == 1)
	{
		precision = ft_get_digits(str + *i + 2, i);
		*i = *i + 2;
	}
	else if (str[*i + 0] == '.' && ft_isdigit(str[*i + 1]) == 1)
	{
		precision = ft_get_digits(str + *i + 1, i);
		*i = *i + 1;
	}
	else if (str[*i + 0] == '.' && ft_isdigit(str[*i + 1]) != 1)
	{
		precision = 0;
		*i = *i + 1;
	}
	else if (str[*i + 1] == '.' && ft_isdigit(str[*i + 2]) != 1)
	{
		precision = 0;
		*i = *i + 2;
	}
	return (precision);
}
