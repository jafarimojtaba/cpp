/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_handle_print_zero_flag.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/20 10:48:10 by mgranero          #+#    #+#             */
/*   Updated: 2022/08/28 23:25:41 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
 The value should be zero padded.  
 For d, i, o, u, x, X, the converted value
 is padded on the left with zeros rather than blanks.  
 If the 0 and - flags both appear, the 0 flag is ignored.
 If a precision is given with a numeric conversion (d, i, o,
 u, x, and X), the 0 flag is ignored.  For other
 conversions, the behavior is undefined.

 Returns:
 The number of characteres printed
*/

#include "ft_printf_bonus.h"

static int	ft_print_zero_flag(char *buff, int number, int cnt_char);
static int	ft_zero_width_precision(char *buff, int precision,
				int number, int len);
static void	ft_initializer(int *number, int *cnt_char, int *precision,
				int *len);
static int	ft_special_case(char *buff, int *number, int precision, int len);

int	ft_handle_print_zero_flag(const char *str, va_list	list, int *i)
{
	char	buff[1000];
	int		number;	
	int		len;
	int		cnt_char;
	int		precision;

	ft_initializer(&number, &cnt_char, &precision, &len);
	ft_reset_buffer(buff, 1000);
	while (str[*i + 2] == '0')
		*i += 1;
	if (ft_isdigit(str[*i + 2]) == 1)
		number = ft_get_digits(str + *i + 2, i);
	*i = *i + 2;
	if (str[*i] == '.')
	{
		precision = ft_get_digits_precision(str, i);
		len = ft_handle_print_by_data_type(str, buff, list, i);
		if (str[*i] == 'i' || str[*i] == 'd' || str[*i] == 'u'
			|| str[*i] == 'x' || str[*i] == 'X')
			return (cnt_char + ft_zero_width_precision(buff, precision,
					number, len));
	}
	if (len == 0)
		cnt_char = ft_handle_print_by_data_type(str, buff, list, i);
	return (ft_print_zero_flag(buff, number, cnt_char));
}

void	ft_initializer(int *number, int *cnt_char, int *precision, int *len)
{
	*number = 0;
	*len = 0;
	*cnt_char = 0;
	*precision = -1;
}

int	ft_zero_width_precision(char *buff, int precision, int number, int len)
{
	int		cnt_char;

	cnt_char = 0;
	if (len < 0)
		len *= -1;
	if (number > 0)
	{
		if (precision > 0 && precision >= len && buff[0] != '0')
			cnt_char += ft_special_case(buff, &number, precision, len);
		else
			cnt_char += ft_print_width(-1, -1, number, len);
		cnt_char -= len;
	}
	if (precision > 0 || (precision == 0 && buff[0] != '0'))
	{
		cnt_char += len;
		cnt_char += ft_print_precision(buff, precision, -1, len);
	}
	else
		while (cnt_char < number)
			cnt_char += ft_handle_print_txt(' ');
	return (cnt_char);
}

static int	ft_special_case(char *buff, int *number, int precision, int len)
{
	int	cnt_char;

	cnt_char = 0;
	*number = *number - precision + len;
	if (buff[0] == '-')
		cnt_char += ft_print_width(-1, -1, *number -1, len);
	else
		cnt_char += ft_print_width(-1, -1, *number, len);
	return (cnt_char);
}

static int	ft_print_zero_flag(char *buff, int number, int cnt_char)
{
	int	start_index;
	int	len;

	start_index = 0;
	if (cnt_char < 0)
	{
		cnt_char *= -1;
		ft_handle_print_txt('-');
		start_index = 1;
	}
	len = cnt_char;
	while (cnt_char < number)
		cnt_char += ft_handle_print_txt('0');
	ft_print_buffer(buff, len, start_index);
	return (cnt_char);
}
