/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_handle_print_space_flag.c                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/20 10:59:27 by mgranero          #+#    #+#             */
/*   Updated: 2022/08/28 23:25:26 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
(a space) A blank should be left before a positive number
(or empty string) produced by a signed conversion.

Returns:
The number of characteres printed
*/

#include "ft_printf_bonus.h"

static int	ft_print_space_flag(char *buff, char str_c, int len, int number);

int	ft_handle_print_space_flag(const char *str, va_list	list, int *i)
{
	char	buff[1000];
	int		size_buff;
	int		cnt_char;
	int		len;
	int		number;	

	size_buff = 1000;
	cnt_char = 0;
	len = 0;
	number = 0;
	ft_reset_buffer(buff, size_buff);
	while (str[*i + 2] == ' ')
		*i += 1;
	if (ft_isdigit(str[*i + 2]) == 1)
	{
		number = ft_get_digits(str + *i + 2, i);
		*i = *i + 2;
	}
	else
		*i = *i + 2;
	len += ft_handle_print_by_data_type(str, buff, list, i);
	if (len < 0)
		len *= -1;
	cnt_char = ft_print_space_flag(buff, str[*i], len, number);
	return (cnt_char);
}

static int	ft_print_space_flag(char *buff, char str_c, int len, int number)
{
	int		cnt_char;

	cnt_char = len;
	if ((cnt_char > 0 && ft_isdigit(buff[0]) == 1) && str_c != 's')
	{
		cnt_char += ft_handle_print_txt(' ');
		ft_print_buffer(buff, len, 0);
	}
	else if (cnt_char == 0 && str_c == 's' && buff[0] == '\0')
	{
		while (cnt_char < number)
			cnt_char += ft_handle_print_txt(' ');
	}
	else if (cnt_char > 0 && str_c == 's' )
	{
		while (cnt_char < number)
			cnt_char += ft_handle_print_txt(' ');
		ft_print_buffer(buff, len, 0);
	}
	else
		ft_print_buffer(buff, len, 0);
	return (cnt_char);
}
