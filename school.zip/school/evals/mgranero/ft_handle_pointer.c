/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_handle_pointer.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/23 14:33:50 by mgranero          #+#    #+#             */
/*   Updated: 2022/08/24 20:49:17 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

static void	ft_initilize_parameters(size_t *tmp, size_t *i, char *char_arr);
static void	ft_write_array(size_t tmp, char	*char_array, size_t	i);
static int	ft_print_reverse_pointer_adress(char *array, size_t i, char *buff);
static int	ft_put_pointer_char(char c, int j, char *buff);

int	ft_handle_pointer(size_t nb, char *buff)
{
	size_t	tmp;
	size_t	i;
	char	char_array[40];

	ft_initilize_parameters(&tmp, &i, char_array);
	if (nb == 0)
	{
		buff[0] = '0';
		buff[1] = 'x';
		buff[2] = '0';
		return (3);
	}
	while (nb > 0)
	{
		tmp = nb % 16;
		ft_write_array(tmp, char_array, i);
		i++;
		if ((nb / 16) == 0 && (nb % 16) > 0)
		{
			char_array[i] = nb / 16;
			break ;
		}
		nb = nb / 16;
	}
	return (ft_print_reverse_pointer_adress(char_array, i, buff));
}

static void	ft_initilize_parameters(size_t *tmp, size_t *i, char *char_arr)
{
	*tmp = 0;
	*i = 0;
	ft_memset((void *)char_arr, '\0', 40);
}

static int	ft_print_reverse_pointer_adress(char *array, size_t i, char *buff)
{
	int	j;

	j = 0;
	buff[j] = '0';
	j++;
	buff[j] = 'x';
	j++;
	while (i)
	{	
		array[i] = ft_tolower(array[i]);
		j = ft_put_pointer_char(array[i], j, buff);
		i--;
		if (i <= 0)
		{
			array[i] = ft_tolower(array[i]);
			j = ft_put_pointer_char(array[i], j, buff);
			return (j);
		}
	}
	return (j);
}

static void	ft_write_array(size_t tmp, char	*char_array, size_t	i)
{
	if (tmp < 10)
	{
		tmp = tmp + 48;
		char_array[i] = tmp;
	}
	else
	{
		tmp = tmp + 55;
		char_array[i] = tmp;
	}	
}

static int	ft_put_pointer_char(char c, int j, char *buff)
{
	if (c != '\0')
	{
		buff[j] = c;
		j++;
	}
	return (j);
}

/*
#include <stdio.h>

int	main(void)
{
	char *str = "this one";
	ft_putpointer_fd(str);
	printf("\n");
	printf("%p\n", str);
	return (0);
}*/