/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_uitoa.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/10 13:22:26 by mgranero          #+#    #+#             */
/*   Updated: 2022/06/13 16:53:14 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
Allocates (with malloc(3)) and returns a string
representing the integer received as an argument.
Negative numbers must be handled.

Paramenter:
	n:  the unsigned integer to convert.

Return:
	The string representing the integer.
	NULL if the allocation fails.

char *ft_uitoa(unsigned int  n);
*/

#include "ft_printf.h"

static int			ft_check_special_case(unsigned int n, char *str_out);
static int			ft_power(int a, int b);
static unsigned int	ft_check_negativ(unsigned int n, char *str_out);
static int			ft_calcu_write_str(unsigned int n, int pow, int *g_i,
						char *str_out);

char	*ft_uitoa(unsigned int n)
{
	char			*str_out;
	int				g_i;
	int				*pt_g_i;
	int				pow;

	str_out = 0;
	g_i = 9;
	pt_g_i = &g_i;
	str_out = (char *)malloc((g_i + 3) * sizeof(char));
	ft_memset(str_out, '\0', (g_i + 3));
	if (str_out == 0)
		return (0);
	if (ft_check_special_case(n, str_out) == 1)
		return (str_out);
	n = ft_check_negativ(n, str_out);
	while (g_i >= 0)
	{
		pow = ft_power(10, g_i);
		if (n >= (unsigned int) pow)
			n = ft_calcu_write_str(n, pow, pt_g_i, str_out);
		else
			g_i = g_i - 1;
	}
	return (str_out);
}

static int	ft_calcu_write_str(unsigned int n, int pow, int *g_i, char *str_out)
{
	int		h;
	char	c;
	int		i;

	h = n / pow;
	c = h + 48;
	i = 0;
	while (str_out[i] != '\0')
		i++;
	str_out[i] = c;
	n = n - h * pow;
	*g_i = *g_i - 1;
	pow = ft_power(10, *g_i);
	while (n < (unsigned int)pow && *g_i >= 0)
	{	
		i = 0;
		while (str_out[i] != '\0')
			i++;
		str_out[i] = '0';
		*g_i = *g_i - 1;
		pow = ft_power(10, *g_i);
	}
	return (n);
}

static int	ft_power(int a, int b)
{
	int	out;
	int	j;

	out = 1;
	j = 1;
	while (j <= b)
	{
		out = out * a;
		j = j + 1;
	}
	return (out);
}

static unsigned int	ft_check_negativ(unsigned int n, char *str_out)
{
	if (n < 0)
	{
		str_out[0] = '-';
		n = -1 * n;
	}
	return (n);
}

static int	ft_check_special_case(unsigned int n, char *str_out)
{
	if (n == 0)
	{
		str_out[0] = '0';
		return (1);
	}
	return (0);
}

/*
#include <stdio.h>
#include <string.h>
#include <unistd.h>

void	ft_print_result(char const *s)
{
	int		len;

	len = 0;
	while (s[len])
		len++;
	write(1, s, len);
}

int	main(void)
{

	// int		n = -2147483648LL;

	// char	*str_out;

	// check special case function
	//str_out = ft_check_special_case(n);
	
	// str_out = ft_itoa(n);
	// char *soll = "-2147483648";

	// if (ft_strncmp(str_out, soll, strlen(soll)) == 0)
	// 	printf("PASS\n");	
	// else 
	// 	printf("FAIL\n");

	//char *res = ft_itoa(-2147483648LL);
	char *res = ft_itoa(2147483647);
		ft_print_result(res);

	//printf("IST: '%s' and lenght %lu", str_out, strlen(str_out));
	//printf("IST: '%s'\n", str_out);
	free(res);
	return (0);
}

#include <stdio.h>

int main(void)
{
	// char n[40] = "99999999999999999999999999";
	// int i1 = atoi(n);
	// int i2 = ft_atoi(n);
	// printf("ist : %d\n", i1);
	// printf("soll: %d\n", i2);

	char* i3 = ft_uitoa(-50);
	printf("Valor unsigned int: %s\n", i3);


	return (0);
}*/