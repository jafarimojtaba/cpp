/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_handle_print_hash_flag.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/20 10:53:17 by mgranero          #+#    #+#             */
/*   Updated: 2022/08/28 23:25:01 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
The first character of the output string is
made zero (by prefixing a 0 if it was not zero already).
For x and X conversions, a nonzero result has the string
"0x" (or "0X" for X conversions) prepended to it.  

Returns:
The number of characteres printed
*/

#include "ft_printf_bonus.h"

int	ft_handle_print_hash_flag(const char *str, va_list	list, int *i, int c)
{
	char	buff[1000];	
	int		size_buff;
	int		cnt_char;	

	size_buff = 1000;
	cnt_char = 0;
	ft_reset_buffer(buff, size_buff);
	*i = *i + 2;
	cnt_char += ft_handle_print_by_data_type(str, buff, list, i);
	if (buff[0] == '0' && cnt_char == 1)
		ft_handle_print_txt('0');
	else
	{
		ft_handle_print_txt('0');
		ft_handle_print_txt(c);
		ft_print_buffer(buff, cnt_char, 0);
		cnt_char += 2;
	}
	return (cnt_char);
}
