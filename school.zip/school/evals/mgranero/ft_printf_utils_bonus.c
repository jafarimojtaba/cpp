/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_utils_bonus.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/20 10:30:14 by mgranero          #+#    #+#             */
/*   Updated: 2022/08/29 14:11:12 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
	Utility functions used for the ft_printf library 
*/

#include "ft_printf_bonus.h"

void	ft_print_buffer(const char *buff, int cnt_char, int init_index)
{
	int	j;

	j = init_index;
	while (j < cnt_char)
	{
		ft_putchar_fd(buff[j], 1);
		j++;
	}	
}

int	ft_get_digits(const char *str, int *i)
{
	char	c_number[21];
	int		j;

	j = 0;
	while (*str != '\0' && ft_isdigit(*str) == 1)
	{
		c_number[j] = *str;
		*i = *i + 1;
		str++;
		j++;
	}
	c_number[j] = '\0';
	return (ft_atoi(c_number));
}

void	ft_reset_buffer( char *buff, int buff_size)
{
	int	j;

	j = 0;
	while (j < buff_size)
	{
		buff[j] = '\0';
		j++;
	}
}

void	ft_initialize_parameters(char *buff, int *cnt_char)
{
	int		size_buff;

	size_buff = 1000;
	*cnt_char = 0;
	ft_reset_buffer(buff, size_buff);
}

int	ft_write_hex_buffer(char *arr, int i, char c_chase, char *buff)
{
	int	cnt;
	int	sw;
	int	j;

	cnt = 0;
	sw = 0;
	j = 0;
	while (i >= 0)
	{
		if (c_chase == 'x')
			arr[i] = ft_tolower(arr[i]);
		if (sw == 0 && arr[i] == '0')
			sw = 0;
		else if (arr[i] != '\0')
		{
			sw = 1;
			buff[j] = arr[i];
			cnt++;
			j++;
		}
		i--;
	}
	return (cnt);
}
