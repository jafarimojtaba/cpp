/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_handle_print_positive_flag.c                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/20 11:02:32 by mgranero          #+#    #+#             */
/*   Updated: 2022/08/28 23:25:21 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*

 A sign (+ or -) should always be placed before a number
 produced by a signed conversion.  By default, a sign is
 used only for negative numbers.  A + overrides a space if
 both are used.
 Writes a positive sign if the a positive numbers was converted by 
 the d, i or u

 Returns:
 The number of characteres printed
*/

#include "ft_printf_bonus.h"

int	ft_handle_print_positive_flag(const char *str, va_list	list, int *i)
{
	char	buff[1000];
	int		size_buff;
	int		cnt_char;
	int		len;

	size_buff = 1000;
	cnt_char = 0;
	len = 0;
	ft_reset_buffer(buff, size_buff);
	while (str[*i + 2] == '+')
		*i += 1;
	*i = *i + 2;
	len += ft_handle_print_by_data_type(str, buff, list, i);
	cnt_char = len;
	if (cnt_char > 0)
		cnt_char += ft_handle_print_txt('+');
	else if (cnt_char < 0)
	{
		len = (-1) * len;
		cnt_char *= -1;
	}		
	ft_print_buffer(buff, len, 0);
	return (cnt_char);
}
