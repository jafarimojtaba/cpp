/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_width.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/23 14:50:52 by mgranero          #+#    #+#             */
/*   Updated: 2022/08/28 23:25:53 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf_bonus.h"

static int	ft_case1(int min, int width, int len);
static int	ft_case2(int max, int width, int len);

int	ft_print_width(int min, int max, int width, int len)
{
	int	cnt_char;

	cnt_char = len;
	if ((max < 0 && min >= 0 && (width - min) > 0)
		|| (max < 0 && min <= 0 && (width - len) > 0))
		cnt_char += ft_case1(min, width, len);
	else if ((min < 0 && max >= 0 && (width - max) > 0)
		|| (min < 0 && max <= 0 && (width - len) > 0))
		cnt_char += ft_case2(max, width, len);
	return (cnt_char);
}

static int	ft_case1(int min, int width, int len)
{
	int	j;
	int	loop;
	int	cnt_char;

	j = 0;
	loop = 0;
	cnt_char = 0;
	if (min <= 0 || (min < len))
		loop = (width - len);
	else
		loop = width - min;
	while (j < loop)
	{
		cnt_char += ft_handle_print_txt(' ');
		j++;
	}
	return (cnt_char);
}

static int	ft_case2(int max, int width, int len)
{
	int	j;
	int	loop;
	int	cnt_char;

	j = 0;
	loop = 0;
	cnt_char = 0;
	if (max < 0)
		loop = (width - len);
	else
		loop = width - max;
	while (j < loop)
	{
		cnt_char += ft_handle_print_txt(' ');
		j++;
	}
	return (cnt_char);
}
