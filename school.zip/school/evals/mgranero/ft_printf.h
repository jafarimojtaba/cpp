/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/16 17:28:43 by mgranero          #+#    #+#             */
/*   Updated: 2022/08/29 13:58:05 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include <stdarg.h>  
# include <stdlib.h>
# include <limits.h>
# include "./libft/libft.h"

int		ft_printf(const char *str, ...);
int		ft_handle_print_txt(char c);
int		ft_handle_char(int c, char *buff);
int		ft_handle_str(char *str, char *buff);
int		ft_handle_int_dec(int value, char *buff);
int		ft_handle_unint(unsigned int ui, char *buff);
int		ft_handle_hex(uint64_t nb, char c_chase, char *buff);
int		ft_handle_pointer(size_t nb, char *buff);
char	*ft_uitoa(unsigned int nb);
void	ft_print_buffer(const char *buff, int cnt_char, int init_index);
void	ft_reset_buffer( char *buff, int buff_size);
int		ft_write_hex_buffer(char *arr, int i, char c_chase, char *buff);

#endif
