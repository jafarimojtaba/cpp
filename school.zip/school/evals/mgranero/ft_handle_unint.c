/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_handle_unint.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/09 21:43:38 by mgranero          #+#    #+#             */
/*   Updated: 2022/08/21 15:32:55 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_handle_unint(unsigned int ui, char *buff)
{
	char	*ptr;
	int		cnt_char;

	ptr = 0;
	cnt_char = 0;
	ptr = ft_uitoa(ui);
	ft_memcpy(buff, ptr, ft_strlen(ptr));
	cnt_char = ft_strlen(ptr);
	*ptr = 0;
	free(ptr);
	return (cnt_char);
}
