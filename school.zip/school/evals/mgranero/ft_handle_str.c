/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_handle_str.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/09 21:42:20 by mgranero          #+#    #+#             */
/*   Updated: 2022/08/21 15:32:38 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_handle_str(char *str, char *buff)
{
	int	cnt_char;

	cnt_char = 0;
	if (str == NULL)
	{
		buff[0] = '(';
		buff[1] = 'n';
		buff[2] = 'u';
		buff[3] = 'l';
		buff[4] = 'l';
		buff[5] = ')';
		cnt_char += 6;
	}
	else if (str[0] != '\0')
	{
		ft_memcpy(buff, str, ft_strlen(str));
		cnt_char += ft_strlen(str);
	}
	return (cnt_char);
}
