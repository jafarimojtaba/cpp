/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_handle_hex.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/23 12:59:21 by mgranero          #+#    #+#             */
/*   Updated: 2022/08/24 21:09:00 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*

Function to convert an int input to a string representing the hex value

Rescale for char and Hexadecimal values
For numbers smaller than 10 -> use the normal decimal to char ASCII conversion
adding + 48 which is the char for '0'
For 10 and higher -> 10 should be equal to 'A'. Therefore we in order to get
a 'A' (65) for a 10 value, we need to add 55.  

*/

#include "ft_printf.h"

static void	ft_initilize_parameters(int *tmp, int *i, char *char_arr);
static int	ft_print_reverse_array(char	*arr, int i, char c_chase, char *buff);
static void	ft_write_array(int tmp, char *char_array, int i);
static int	ft_check_zero_array(const char	*array, int i);

int	ft_handle_hex(uint64_t nb, char c_chase, char *buff)
{
	int		tmp;
	int		i;
	char	char_array[10];

	ft_initilize_parameters(&tmp, &i, char_array);
	if (c_chase != 'x' && c_chase != 'X')
		return (0);
	else if (nb == 0)
	{
		buff[0] = '0';
		return (1);
	}
	while (nb > 0 && i < 8)
	{
		tmp = nb % 16;
		ft_write_array(tmp, char_array, i);
		i++;
		if ((nb / 16) == 0)
			break ;
		nb = nb / 16;
	}
	return (ft_print_reverse_array(char_array, i, c_chase, buff));
}

static void	ft_initilize_parameters(int *tmp, int *i, char *char_arr)
{
	*tmp = 0;
	*i = 0;
	ft_memset((void *)char_arr, '\0', 10);
}

static void	ft_write_array(int tmp, char *char_array, int i)
{
	if (tmp < 10)
	{
		tmp = tmp + 48;
		char_array[i] = tmp;
	}
	else
	{
		tmp = tmp + 55;
		char_array[i] = tmp;
	}	
}

static int	ft_print_reverse_array(char	*arr, int i, char c_chase, char *buff)
{
	if (ft_check_zero_array (arr, i) == i)
	{
		buff[0] = '0';
		return (1);
	}
	return (ft_write_hex_buffer(arr, i, c_chase, buff));
}

static int	ft_check_zero_array(const char	*array, int i)
{
	int	cnt_zeros;
	int	j;

	cnt_zeros = 0;
	j = 0;
	while (j < i)
	{
		if (array[j] == '0')
		{
			cnt_zeros++;
		}
		j++;
	}
	return (cnt_zeros);
}

/*
#include <stdio.h>

int	main(void)
{
	// ft_put_hex_fd(1128, 'x');
	// printf("\n");
	// printf("printf(1128) says: %x\n", 1128);
	// ft_put_hex_fd(188, 'x');
	// printf("\n");
	// printf("printf(188) says: %x\n", 188);
	// ft_put_hex_fd(399, 'X');
	// printf("\n");
	// printf("printf(399) says: %X\n", 399);
	int i;
	i = 0;
	//ft_handle_print_char('A', &i);
	// ft_handle_print_char('%', &i);
	// ft_handle_print_str("42", &i);
	// ft_handle_print_char('%', &i);
	// ft_handle_print_int_dec(42, &i);
	// ft_handle_print_char('%', &i);
	// ft_handle_print_int_dec(42, &i);
	// ft_handle_print_char('%', &i);
	// ft_handle_print_hex(42, 'x', &i);
	// ft_handle_print_char('%', &i);
	ft_handle_print_hex(42, 'X', &i);

	return (0);
}*/