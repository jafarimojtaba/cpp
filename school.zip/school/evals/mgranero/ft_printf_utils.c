/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_utils.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/20 10:30:14 by mgranero          #+#    #+#             */
/*   Updated: 2022/08/29 13:55:38 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
	Utility functions used for the ft_printf library 
*/

#include "ft_printf.h"

void	ft_print_buffer(const char *buff, int cnt_char, int init_index)
{
	int	j;

	j = init_index;
	while (j < cnt_char)
	{
		ft_putchar_fd(buff[j], 1);
		j++;
	}	
}

void	ft_reset_buffer( char *buff, int buff_size)
{
	int	j;

	j = 0;
	while (j < buff_size)
	{
		buff[j] = '\0';
		j++;
	}
}

int	ft_write_hex_buffer(char *arr, int i, char c_chase, char *buff)
{
	int	cnt;
	int	sw;
	int	j;

	cnt = 0;
	sw = 0;
	j = 0;
	while (i >= 0)
	{
		if (c_chase == 'x')
			arr[i] = ft_tolower(arr[i]);
		if (sw == 0 && arr[i] == '0')
			sw = 0;
		else if (arr[i] != '\0')
		{
			sw = 1;
			buff[j] = arr[i];
			cnt++;
			j++;
		}
		i--;
	}
	return (cnt);
}
