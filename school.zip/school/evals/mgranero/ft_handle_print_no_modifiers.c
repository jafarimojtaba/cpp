/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_handle_print_no_modifiers.c                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/20 11:05:07 by mgranero          #+#    #+#             */
/*   Updated: 2022/08/28 23:25:15 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
 Handles the buffer if no modifiers are used but it calls the the handle for 
 conversions
 
 Returns:
 The number of characteres printed
*/

#include "ft_printf_bonus.h"

int	ft_handle_print_no_modifiers(const char *str, va_list	list, int *i)
{
	char	buff[1000];
	int		size_buff;
	int		cnt_char;

	size_buff = 1000;
	cnt_char = 0;
	ft_reset_buffer(buff, size_buff);
	*i = *i + 1;
	cnt_char += ft_handle_print_by_data_type(str, buff, list, i);
	if (cnt_char < 0)
		cnt_char *= -1;
	ft_print_buffer(buff, cnt_char, 0);
	return (cnt_char);
}
