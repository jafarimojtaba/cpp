/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_handle_print_minus_flag.c                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/20 10:42:45 by mgranero          #+#    #+#             */
/*   Updated: 2022/08/28 23:25:09 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
 The converted value is to be left adjusted on the field
 boundary.  (The default is right justification.)  The
 converted value is padded on the right with blanks, rather
 than on the left with blanks or zeros.  A - overrides a 0
 if both are given.

 Returns:
 The number of characteres printed
*/

#include "ft_printf_bonus.h"

static void	ft_initializer(int *number, int *cnt_char, int *precision,
				char *buff);
static int	ft_minus_precision(char *buff, char str, int precision,
				int len);
static int	ft_handle_space(char *buff, int cnt_char, int number);
static int	ft_fc_reducer(const char *str, int *i);

int	ft_handle_print_minus_flag(const char *str, va_list	list, int *i)
{
	char	buff[1000];
	int		cnt_char;
	int		number;
	int		precision;
	int		len;

	ft_initializer(&number, &cnt_char, &precision, buff);
	number = ft_fc_reducer(str, i);
	if (str[*i] == '.')
	{
		precision = ft_get_digits_precision(str, i);
		len = ft_handle_print_by_data_type(str, buff, list, i);
		if (len < 0)
			len *= -1;
		cnt_char = ft_minus_precision(buff, str[*i], precision, len);
	}
	else
	{
		cnt_char = ft_handle_print_by_data_type(str, buff, list, i);
		if (cnt_char < 0)
			cnt_char *= -1;
		ft_print_buffer(buff, cnt_char, 0);
	}
	cnt_char = ft_handle_space(buff, cnt_char, number);
	return (cnt_char);
}	

static int	ft_fc_reducer(const char *str, int *i)
{
	int	number;

	number = 0;
	while (str[*i + 2] == '-')
		*i += 1;
	if (ft_isdigit(str[*i + 2]) == 1)
		number = ft_get_digits(str + *i + 2, i);
	*i = *i + 2;
	return (number);
}

static int	ft_handle_space(char *buff, int cnt_char, int number)
{
	if (buff[0] == '\0' && cnt_char == 1 && number == 1)
		ft_handle_print_txt('\0');
	else
	{
		while (cnt_char < number)
			cnt_char += ft_handle_print_txt(' ');
	}
	return (cnt_char);
}

static int	ft_minus_precision(char *buff, char str, int precision, int len)
{
	int	cnt_char;

	cnt_char = len;
	if (buff[0] == '0' && precision == 0 && (str == 'i'
			|| str == 'd'
			|| str == 'u' || str == 'x' || str == 'X'))
			cnt_char = 0;
	else if (str == 'd' || str == 'i' || str == 'u'
		|| str == 'x' || str == 'X')
			cnt_char += ft_print_precision(buff, precision, -1, len);
	else
		cnt_char += ft_print_precision(buff, -1, precision, len);
	return (cnt_char);
}

static void	ft_initializer(int *number, int *cnt_char, int *precision,
				char *buff)
{
	*number = 0;
	*cnt_char = 0;
	*precision = 0;
	ft_reset_buffer(buff, 1000);
}
