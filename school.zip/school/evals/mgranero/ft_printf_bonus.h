/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_bonus.h                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/16 17:28:43 by mgranero          #+#    #+#             */
/*   Updated: 2022/08/29 14:40:05 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_BONUS_H
# define FT_PRINTF_BONUS_H

# include <stdarg.h>  
# include <stdlib.h>
# include <limits.h>
# include "./libft/libft.h"
# include "ft_printf.h"

int		ft_get_digits(const char *str, int *i);
void	ft_initialize_parameters(char *buff, int *cnt_char);
int		ft_handle_print_width_precision(const char *str, va_list list, int *i);
int		ft_get_digits_precision(const char *str, int *i);
int		ft_print_precision(char *buff, int min, int max, int len);
int		ft_print_width(int min, int max, int width, int len);
int		ft_write_hex_buffer(char *arr, int i, char c_chase, char *buff);
int		ft_handle_print_minus_flag(const char *str, va_list list, int *i);
int		ft_handle_print_zero_flag(const char *str, va_list list, int *i);
int		ft_handle_print_hash_flag(const char *str, va_list list, int *i, int c);
int		ft_handle_print_space_flag(const char *str, va_list	list, int *i);
int		ft_handle_print_positive_flag(const char *str, va_list list, int *i);
int		ft_handle_print_no_modifiers(const char *str, va_list list, int *i);
int		ft_handle_print_by_data_type(const char *str, char *buff,
			va_list	list, int *i);
int		ft_get_width_precision(const char *str, char *buff,
			int *i, va_list list);
int		ft_get_width_precision(const char *str, char *buff,
			int *i, va_list list);
#endif
