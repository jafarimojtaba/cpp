/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_handle_print_int_dec.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mgranero <mgranero@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/09 21:41:10 by mgranero          #+#    #+#             */
/*   Updated: 2022/08/21 15:31:45 by mgranero         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
 The int argument is converted to signed decimal notation.
 The precision, if any, gives the minimum number of digits
 that must appear; if the converted value requires fewer
 digits, it is padded on the left with zeros.  The default
 precision is 1.  When 0 is printed with an explicit
 precision 0, the output is empty.

 Returns:
 The number of characters written in the Buffer
*/

#include "ft_printf.h"

int	ft_handle_int_dec(int value, char *buff)
{
	char	*ptr;
	int		len;

	ptr = 0;
	ptr = ft_itoa(value);
	len = ft_strlen(ptr);
	ft_memcpy(buff, ptr, len);
	*ptr = 0;
	free(ptr);
	if (value < 0)
		return (-1 * len);
	return (+1 * len);
}
