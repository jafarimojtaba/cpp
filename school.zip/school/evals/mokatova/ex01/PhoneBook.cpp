/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   PhoneBook.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mokatova <mokatova@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/15 19:55:10 by mokatova          #+#    #+#             */
/*   Updated: 2022/07/31 15:53:34 by mokatova         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "PhoneBook.hpp"

PhoneBook::PhoneBook(void) {

}

PhoneBook::~PhoneBook(void) {
	
}

void PhoneBook::add(int i) {
	std::string first, last, nick, number, secret;		
	
	std::cout << "Enter the first name: " << std::endl;
	std::getline(std::cin, first);
	std::cout << "Enter the last name: " << std::endl;
	std::getline(std::cin, last);
	std::cout << "Enter the nickname: " << std::endl;
	std::getline(std::cin, nick);
	std::cout << "Enter the phone number: " << std::endl;
	std::getline(std::cin, number);
	std::cout << "And now, this person's darkest secret, please: " << std::endl;
	std::getline(std::cin, secret);
	this->_contacts[i] = Contact(first, last, nick, number, secret);
	std::cout << "The contact has been successfully added!" << std::endl;
}

void trunc_n_print(std::string data)
{
	if (data.length() > 10)
	{
		data = data.substr(0, 10);
		data.replace(9, 1, ".");
	}
	std::cout << std::setw(10);
	std::cout << data;
}

void PhoneBook::search(int i) {
	std::string	input;
	if (i == 0) {
		std::cout << "\nYou need to add some contacts first, my friend" << std::endl;
		return ;
	}
	if (i > 8) {
		i = 8;
	}
	for (int j = 0; j < i; j++) {
		std::cout << std::setw(10);
		std::cout << j + 1 << " | ";
		trunc_n_print(this->_contacts[j].getFirstName());
		std::cout << " | ";
		trunc_n_print(this->_contacts[j].getLastName());
		std::cout << " | ";
		trunc_n_print(this->_contacts[j].getNickName());
		std::cout << std::endl;
	}
	std::cout << "What entry do you wish to look at? Type the index: " << std::endl;
	std::getline(std::cin, input);
	int j = atoi(input.c_str());
	if (j <= i && j > 0) {
		std::cout << this->_contacts[j - 1].getFirstName() << std::endl;
		std::cout << this->_contacts[j - 1].getLastName() << std::endl;
		std::cout << this->_contacts[j - 1].getNickName() << std::endl;
	}
	else {
		std::cout << "\nLook through the printed phone book and pick an existing index" << std::endl;
	}
}
