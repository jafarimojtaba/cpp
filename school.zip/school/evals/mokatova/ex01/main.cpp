/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mokatova <mokatova@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/15 19:55:01 by mokatova          #+#    #+#             */
/*   Updated: 2022/07/31 15:50:14 by mokatova         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "PhoneBook.hpp"

int	main(void) {
	int	i = 0;
	PhoneBook	phoneBook;
	std::string	input;
	
	while (true) {
		std::cout << "\n___Enter one of the following commands: ADD, SEARCH, EXIT___\n" << std::endl;
		std::getline(std::cin, input);
		if (input == "EXIT") {
			break ;
		}
		else if (input == "ADD") {
			phoneBook.add(i % 8);
			i++;
		}
		else if (input == "SEARCH") {
			phoneBook.search(i);
		}
		else {
			std::cout << "\nCheck for typos, my friend, only above-mentioned commands are allowed" << std::endl;
		}
	}
	return (0);
}
