/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Contact.cpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mokatova <mokatova@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/15 19:55:05 by mokatova          #+#    #+#             */
/*   Updated: 2022/07/29 16:24:53 by mokatova         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Contact.hpp"

Contact::Contact(void) {
	
}

Contact::Contact(std::string firstName, std::string lastName,
			std::string nickName, std::string phoneNumber,
			std::string darkestSecret) : _firstName(firstName),
			_lastName(lastName), _nickName(nickName),
			_phoneNumber(phoneNumber), _darkestSecret(darkestSecret) {
				
}

Contact::~Contact(void) {
	
}

void Contact::setFirstName(std::string name) {
	this->_firstName = name;
}

std::string Contact::getFirstName(void) {
	return (this->_firstName);
}

void Contact::setLastName(std::string name) {
	this->_lastName = name;
}

std::string Contact::getLastName(void) {
	return (this->_lastName);
}

void Contact::setNickName(std::string name) {
	this->_nickName = name;
}

std::string Contact::getNickName(void) {
	return (this->_nickName);
}

void Contact::setPhoneNumber(std::string number) {
	this->_phoneNumber = number;
}

std::string Contact::getPhoneNumber(void) {
	return (this->_phoneNumber);
}

void Contact::setDarkestSecret(std::string secret) {
	this->_darkestSecret = secret;
}

std::string Contact::getDarkestSecret(void) {
	return (this->_darkestSecret);
}