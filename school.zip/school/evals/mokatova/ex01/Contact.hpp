/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Contact.hpp                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mokatova <mokatova@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/15 19:55:39 by mokatova          #+#    #+#             */
/*   Updated: 2022/07/31 15:03:25 by mokatova         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CONTACT_HPP
# define CONTACT_HPP

# include <iostream>
# include <iomanip>

class Contact {
	
public:
	Contact(void);
	Contact(std::string firstName, std::string lastName, std::string nickName,
			std::string phoneNumber, std::string darkestSecret);
	~Contact(void);

	void setFirstName(std::string name);
	std::string getFirstName(void);
	void setLastName(std::string name);
	std::string getLastName(void);
	void setNickName(std::string name);
	std::string getNickName(void);
	void setPhoneNumber(std::string number);
	std::string getPhoneNumber(void);
	void setDarkestSecret(std::string secret);
	std::string getDarkestSecret(void);

private:
	std::string _firstName;
	std::string _lastName;
	std::string _nickName;
	std::string _phoneNumber;
	std::string _darkestSecret;
	
};

#endif