/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   megaphone.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mokatova <mokatova@student.42wolfsburg.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/15 18:57:27 by mokatova          #+#    #+#             */
/*   Updated: 2022/07/15 19:40:49 by mokatova         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>

void	upperPrint(char *str) {
	int i = 0;

	while (str[i]) {
		if (str[i] >= 'a' && str[i] <= 'z') {
			str[i] -= 32;
		}
		std::cout << str[i++];
	}
}

int	main(int argc, char **argv) {
	if (argc == 1) {
		std::cout << "* LOUD AND UNBEARABLE FEEDBACK NOISE *" << std::endl;
	}
	else {
		for (int i = 1; i < argc; i++) {
			upperPrint(argv[i]);
		}
		std::cout << std::endl;
	}
	return (0);
}
