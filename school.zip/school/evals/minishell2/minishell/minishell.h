//
// Created by Grish on 06.08.2021.
//

#ifndef MINISHELL_MINISHELL_H
#define MINISHELL_MINISHELL_H


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <readline/readline.h>
#include <readline/history.h>
#include "./libft/libft.h"

#endif //MINISHELL_MINISHELL_H
