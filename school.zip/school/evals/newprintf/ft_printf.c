/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mjafari <mjafari@student.42wolfsburg.de>   +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/23 10:31:23 by mgranero          #+#    #+#             */
/*   Updated: 2022/09/04 19:45:59 by mjafari          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*
Recode the printf() function from libc. 
The prototype of ft_printf() is:
	int    ft_printf(const char *, .
Buffer management from printf not implemented

printf format
%[ $] [flags] [width] [.precision] [length modifier] conversion
	conversion starts with $
	0 or more flags
	optional field width
	optional precision 
	optional length modifier
ends with conversion specifier : like s,p,c,d,u,x,X,

Implemented conversions (mandatory):
%c Prints a single character.   
%s Prints a string (as defined by the common C convention).
%p The void * pointer argument has to be printed in 
    hexadecimal format. 
%d Prints a decimal (base 10) number. 
%i Prints an integer in base 10.
%u Prints an unsigned decimal (base 10) number.
%x Prints a number in hexadecimal (base 16) lowercase format.
%X Prints a number in hexadecimal (base 16) uppercase format.
%% Prints a percent sign.

Implemented modifiers (bonus):

	width
	precision

Flags
	- with field minimum width under all conversions.
	0 with field minimum width under all conversions.
	. with field minimum width under all conversions.
	#
	space
	+

Returns:
It returns the number of characters that are printed. 
If there is some error then it returns a negative value.
*/

#include "ft_printf.h"

static int	ft_handle_buffer(int *len, char *buff);
static void	ft_initializer(int *i, int *cnt_char, char *buff);
static int	ft_handle_conversion(const char *str, char *buff,
				va_list list, int *i);

int	ft_printf(const char *str, ...)
{
	va_list	list;
	int		i;
	int		cnt_char;
	char	buff[1000];

	ft_initializer(&i, &cnt_char, buff);
	if (str[0] == '\0' || str == 0)
		return (0);
	va_start(list, str);
	while (str[i] != '\0')
	{
		if (str[i] == '%')
			cnt_char += ft_handle_conversion(str, buff, list, &i);
		else
			cnt_char += ft_handle_print_txt(str[i]);
		if (cnt_char < 0 || cnt_char < -1000)
			return (-1);
		i++;
	}
	va_end(list);
	return (cnt_char);
}

int	ft_handle_print_by_data_type(const char *str, char *buff,
				va_list	list, int *i)
{
	int	cnt;

	cnt = 0;
	if (str[*i] == 'c')
		cnt = ft_handle_char(va_arg(list, int), buff);
	else if (str[*i] == 'i' || str[*i] == 'd')
		cnt = ft_handle_int_dec(va_arg(list, int), buff);
	else if (str[*i] == 'u')
		cnt = ft_handle_unint(va_arg(list, unsigned int), buff);
	else if (str[*i] == 's')
		cnt = ft_handle_str(va_arg (list, char *), buff);
	else if (str[*i] == 'x' || str[*i] == 'X')
		cnt = ft_handle_hex(va_arg(list, uint64_t), str[*i], buff);
	else if (str[*i] == 'p')
		cnt = ft_handle_pointer(va_arg(list, size_t), buff);
	else if (str[*i] == '%')
		cnt = ft_handle_char('%', buff);
	else
		cnt = -1 * (1000 + 5);
	return (cnt);
}

static void	ft_initializer(int *i, int *cnt_char, char *buff)
{
	*i = 0;
	*cnt_char = 0;
	ft_reset_buffer(buff, 1000);
}

static int	ft_handle_buffer(int *len, char *buff)
{
	if (*len < 0)
	*len *= -1;
	ft_print_buffer(buff, *len, 0);
	return (*len);
}

static int	ft_handle_conversion(const char *str, char *buff,
				va_list list, int *i)
{
	int	len;
	int	cnt_char;

	len = 0;
	*i = *i + 1;
	len = ft_handle_print_by_data_type(str, buff, list, i);
	cnt_char = ft_handle_buffer(&len, buff);
	return (cnt_char);
}

/*
#include <stdio.h>

int main (void)
{
	printf("Should: %d\n",       printf("%c", 'm'));
	printf("Is: %d\n",    ft_printf("%c", 'm'));
}
*/
