#include <stdio.h>
#include "ft_printf.h"

int main (void)
{
	printf("Should: %d\n",       printf("%s ",""));
	printf("Is: %d\n",    ft_printf("%s ",""));
}